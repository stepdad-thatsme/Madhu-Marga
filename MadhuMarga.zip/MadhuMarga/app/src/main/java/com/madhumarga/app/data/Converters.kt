package com.madhumarga.app.data

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun honeyFlowToString(level: HoneyFlowLevel): String = level.name

    @TypeConverter
    fun stringToHoneyFlow(value: String): HoneyFlowLevel = HoneyFlowLevel.valueOf(value)

    @TypeConverter
    fun activityToString(level: ActivityLevel): String = level.name

    @TypeConverter
    fun stringToActivity(value: String): ActivityLevel = ActivityLevel.valueOf(value)
}
