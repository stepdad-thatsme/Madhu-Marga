package com.madhumarga.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "hives")
data class HiveEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val tag: String,
    val location: String,
    val createdAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(
    tableName = "inspections",
    foreignKeys = [
        ForeignKey(
            entity = HiveEntity::class,
            parentColumns = ["id"],
            childColumns = ["hiveId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("hiveId")]
)
data class InspectionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hiveId: Long,
    val date: Long = System.currentTimeMillis(),
    val queenSeen: Boolean,
    val pestsSeen: Boolean,
    val honeyFlow: HoneyFlowLevel,
    val activityLevel: ActivityLevel,
    val temperatureC: Float? = null,
    val notes: String = ""
)

@Entity(
    tableName = "harvests",
    foreignKeys = [
        ForeignKey(
            entity = HiveEntity::class,
            parentColumns = ["id"],
            childColumns = ["hiveId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("hiveId")]
)
data class HarvestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hiveId: Long,
    val date: Long = System.currentTimeMillis(),
    val quantityKg: Float,
    val notes: String = ""
)

enum class HoneyFlowLevel { NONE, LOW, MEDIUM, HIGH }
enum class ActivityLevel { LOW, NORMAL, HIGH }
