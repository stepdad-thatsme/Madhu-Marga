package com.madhumarga.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LocalFlorist
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.madhumarga.app.domain.FloraBloom
import com.madhumarga.app.domain.FloraCalendar
import com.madhumarga.app.ui.theme.Honey
import com.madhumarga.app.ui.theme.HoneyDark
import com.madhumarga.app.ui.theme.Leaf

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FloraCalendarScreen(onBack: () -> Unit) {
    var month by remember { mutableIntStateOf(FloraCalendar.currentMonth()) }
    val blooms = FloraCalendar.bloomsInMonth(month)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Flora Calendar") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Honey,
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Text(
                    FloraCalendar.monthName(month),
                    style = MaterialTheme.typography.titleLarge
                )
            }
            item {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items((1..12).toList()) { m ->
                        FilterChip(
                            selected = m == month,
                            onClick = { month = m },
                            label = { Text(FloraCalendar.monthName(m).take(3)) }
                        )
                    }
                }
            }
            if (blooms.isEmpty()) {
                item {
                    Text(
                        "No major blooms tracked for this month yet.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                items(blooms) { BloomCard(it) }
            }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}

@Composable
private fun BloomCard(bloom: FloraBloom) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                Icons.Default.LocalFlorist,
                contentDescription = null,
                tint = Leaf,
                modifier = Modifier.size(28.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(bloom.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    bloom.region,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Rating("Nectar", bloom.nectarRating)
                    Rating("Pollen", bloom.pollenRating)
                }
                Spacer(Modifier.height(6.dp))
                Text(bloom.notes, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun Rating(label: String, value: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("$label: ", style = MaterialTheme.typography.bodyMedium)
        repeat(5) { i ->
            Box(
                Modifier
                    .size(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(if (i < value) HoneyDark else Color.LightGray.copy(alpha = 0.4f))
            )
            Spacer(Modifier.width(2.dp))
        }
    }
}
