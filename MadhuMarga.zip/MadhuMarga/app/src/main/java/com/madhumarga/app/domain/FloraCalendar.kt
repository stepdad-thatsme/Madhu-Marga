package com.madhumarga.app.domain

import java.util.Calendar

data class FloraBloom(
    val name: String,
    val region: String,
    val monthStart: Int, // 1 = January
    val monthEnd: Int,
    val nectarRating: Int, // 1..5
    val pollenRating: Int, // 1..5
    val notes: String
)

/**
 * A starter Flora Calendar tailored to India / Karnataka context (Madhu-Marga is a
 * project for Indian beekeepers). Edit freely or expand by region.
 */
object FloraCalendar {

    val blooms: List<FloraBloom> = listOf(
        FloraBloom("Mustard (Sarson)", "North India", 11, 2, 5, 4,
            "Major winter nectar source for managed colonies."),
        FloraBloom("Coriander", "Pan-India", 1, 3, 4, 3,
            "Good supplementary nectar during late winter."),
        FloraBloom("Eucalyptus", "Karnataka, Tamil Nadu", 11, 2, 5, 3,
            "Heavy flow when in bloom; check plantations."),
        FloraBloom("Coconut Palm", "Coastal India", 1, 12, 3, 3,
            "Year-round mild source in coastal districts."),
        FloraBloom("Drumstick (Moringa)", "South India", 2, 4, 3, 3,
            "Useful spring transition flora."),
        FloraBloom("Neem", "Pan-India", 3, 5, 3, 2,
            "Pre-monsoon bloom; medicinal honey."),
        FloraBloom("Mango", "Pan-India", 1, 3, 3, 4,
            "Early-spring; helps colony build up."),
        FloraBloom("Sunflower", "Karnataka, Maharashtra", 6, 10, 5, 5,
            "Major monsoon/post-monsoon flow crop."),
        FloraBloom("Tulsi (Holy Basil)", "Pan-India", 7, 10, 2, 3,
            "Mild but reliable monsoon source."),
        FloraBloom("Litchi", "Bihar, Uttarakhand", 3, 4, 5, 3,
            "Short, intense bloom — plan migration."),
        FloraBloom("Sesame (Til)", "North & Central India", 8, 10, 4, 3,
            "Monsoon to post-monsoon source."),
        FloraBloom("Rubber", "Kerala, NE India", 1, 3, 5, 2,
            "Extra-floral nectaries; strong flow.")
    )

    /** Blooms active in the given month (1..12), handling wrap-around (e.g. Nov–Feb). */
    fun bloomsInMonth(month: Int): List<FloraBloom> = blooms.filter {
        if (it.monthStart <= it.monthEnd) {
            month in it.monthStart..it.monthEnd
        } else {
            month >= it.monthStart || month <= it.monthEnd
        }
    }

    fun currentMonth(): Int = Calendar.getInstance().get(Calendar.MONTH) + 1

    fun monthName(month: Int): String = listOf(
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    )[(month - 1).coerceIn(0, 11)]
}
