package com.madhumarga.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Honey,
    onPrimary = Color.Black,
    primaryContainer = HoneyLight,
    onPrimaryContainer = EarthDark,
    secondary = Leaf,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFD3E8CF),
    onSecondaryContainer = LeafDark,
    tertiary = Earth,
    onTertiary = Color.White,
    background = Cream,
    onBackground = EarthDark,
    surface = Color.White,
    onSurface = EarthDark,
    surfaceVariant = Color(0xFFFFEEC2),
    onSurfaceVariant = EarthDark,
    error = AlertRed,
    onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = Honey,
    onPrimary = Color.Black,
    primaryContainer = HoneyDark,
    onPrimaryContainer = Cream,
    secondary = Leaf,
    onSecondary = Color.White,
    background = Color(0xFF1A140A),
    onBackground = Cream,
    surface = Color(0xFF241B0E),
    onSurface = Cream,
    error = AlertRed,
    onError = Color.White
)

@Composable
fun MadhuMargaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = AppTypography,
        content = content
    )
}
