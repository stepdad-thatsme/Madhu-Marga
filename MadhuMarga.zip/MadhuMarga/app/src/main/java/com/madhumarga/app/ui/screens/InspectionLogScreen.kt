package com.madhumarga.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.madhumarga.app.data.ActivityLevel
import com.madhumarga.app.data.HiveEntity
import com.madhumarga.app.data.HoneyFlowLevel
import com.madhumarga.app.ui.HiveViewModel
import com.madhumarga.app.ui.theme.Honey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InspectionLogScreen(
    vm: HiveViewModel,
    onSaved: () -> Unit,
    onBack: () -> Unit
) {
    val hives by vm.hives.collectAsState()
    var selectedHive by remember { mutableStateOf<HiveEntity?>(null) }
    var queenSeen by remember { mutableStateOf(true) }
    var pestsSeen by remember { mutableStateOf(false) }
    var honeyFlow by remember { mutableStateOf(HoneyFlowLevel.MEDIUM) }
    var activity by remember { mutableStateOf(ActivityLevel.NORMAL) }
    var tempText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var menuExpanded by remember { mutableStateOf(false) }

    // Default to first hive when list arrives
    if (selectedHive == null && hives.isNotEmpty()) selectedHive = hives.first()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Inspection Log") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Honey,
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (hives.isEmpty()) {
                Text(
                    "Register a hive first before logging an inspection.",
                    style = MaterialTheme.typography.bodyMedium
                )
                return@Column
            }

            ExposedDropdownMenuBox(
                expanded = menuExpanded,
                onExpandedChange = { menuExpanded = !menuExpanded }
            ) {
                OutlinedTextField(
                    value = selectedHive?.tag ?: "",
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Hive") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(menuExpanded) },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth()
                )
                ExposedDropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false }
                ) {
                    hives.forEach { h ->
                        DropdownMenuItem(
                            text = { Text("${h.tag} — ${h.location.ifBlank { "no location" }}") },
                            onClick = {
                                selectedHive = h
                                menuExpanded = false
                            }
                        )
                    }
                }
            }

            ObservationCard("Queen sighted", queenSeen) { queenSeen = it }
            ObservationCard("Pests seen", pestsSeen) { pestsSeen = it }

            Text("Honey flow", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                HoneyFlowLevel.values().forEach { lvl ->
                    FilterChip(
                        selected = honeyFlow == lvl,
                        onClick = { honeyFlow = lvl },
                        label = { Text(lvl.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            Text("Activity level", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                ActivityLevel.values().forEach { lvl ->
                    FilterChip(
                        selected = activity == lvl,
                        onClick = { activity = lvl },
                        label = { Text(lvl.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }

            OutlinedTextField(
                value = tempText,
                onValueChange = { tempText = it.filter { c -> c.isDigit() || c == '.' || c == '-' } },
                label = { Text("Temperature °C (optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
            )

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    val hive = selectedHive ?: return@Button
                    vm.addInspection(
                        hiveId = hive.id,
                        queenSeen = queenSeen,
                        pestsSeen = pestsSeen,
                        honeyFlow = honeyFlow,
                        activityLevel = activity,
                        temperatureC = tempText.toFloatOrNull(),
                        notes = notes.trim()
                    ) { onSaved() }
                },
                enabled = selectedHive != null,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Save Inspection") }
        }
    }
}

@Composable
private fun ObservationCard(
    label: String,
    value: Boolean,
    onChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, modifier = Modifier.weight(1f))
            Switch(checked = value, onCheckedChange = onChange)
        }
    }
}
