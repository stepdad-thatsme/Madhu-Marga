package com.madhumarga.app.data

import kotlinx.coroutines.flow.Flow

class HiveRepository(
    private val hiveDao: HiveDao,
    private val inspectionDao: InspectionDao,
    private val harvestDao: HarvestDao
) {
    fun observeHives(): Flow<List<HiveEntity>> = hiveDao.observeAll()
    fun observeHive(id: Long): Flow<HiveEntity?> = hiveDao.observeById(id)
    suspend fun getHive(id: Long): HiveEntity? = hiveDao.getById(id)
    suspend fun upsertHive(hive: HiveEntity): Long =
        if (hive.id == 0L) hiveDao.insert(hive) else { hiveDao.update(hive); hive.id }
    suspend fun deleteHive(id: Long) = hiveDao.deleteById(id)

    fun observeInspections(hiveId: Long): Flow<List<InspectionEntity>> =
        inspectionDao.observeForHive(hiveId)
    fun observeMostRecentInspection(): Flow<InspectionEntity?> =
        inspectionDao.observeMostRecent()
    suspend fun mostRecentInspectionFor(hiveId: Long): InspectionEntity? =
        inspectionDao.mostRecentForHive(hiveId)
    suspend fun addInspection(inspection: InspectionEntity): Long =
        inspectionDao.insert(inspection)

    fun observeAllHarvests(): Flow<List<HarvestEntity>> = harvestDao.observeAll()
    fun observeHarvests(hiveId: Long): Flow<List<HarvestEntity>> =
        harvestDao.observeForHive(hiveId)
    suspend fun addHarvest(harvest: HarvestEntity): Long = harvestDao.insert(harvest)
}
