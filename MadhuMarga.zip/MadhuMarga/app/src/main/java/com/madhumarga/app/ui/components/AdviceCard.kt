package com.madhumarga.app.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.madhumarga.app.domain.Advice
import com.madhumarga.app.domain.AlertSeverity
import com.madhumarga.app.ui.theme.AlertRed
import com.madhumarga.app.ui.theme.Honey
import com.madhumarga.app.ui.theme.Leaf

@Composable
fun AdviceCard(advice: Advice, modifier: Modifier = Modifier) {
    val (icon, tint, bg) = when (advice.severity) {
        AlertSeverity.CRITICAL -> Triple(Icons.Default.Warning, Color.White, AlertRed)
        AlertSeverity.WARNING -> Triple(Icons.Default.Warning, Color.Black, Honey)
        AlertSeverity.INFO -> Triple(Icons.Default.Info, Color.White, Leaf)
    }
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = bg)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(
                    advice.title,
                    color = tint,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    advice.message,
                    color = tint,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
