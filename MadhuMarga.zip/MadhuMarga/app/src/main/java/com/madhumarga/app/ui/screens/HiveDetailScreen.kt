package com.madhumarga.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.madhumarga.app.domain.HiveAdvisor
import com.madhumarga.app.ui.HiveViewModel
import com.madhumarga.app.ui.components.AdviceCard
import com.madhumarga.app.ui.components.HoneyFlowBar
import com.madhumarga.app.ui.components.SectionHeader
import com.madhumarga.app.ui.theme.Honey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HiveDetailScreen(
    vm: HiveViewModel,
    hiveId: Long,
    onBack: () -> Unit
) {
    val hive by remember(hiveId) { vm.hive(hiveId) }.collectAsState(initial = null)
    val inspections by remember(hiveId) { vm.inspectionsFor(hiveId) }
        .collectAsState(initial = emptyList())
    val harvests by remember(hiveId) { vm.harvestsFor(hiveId) }
        .collectAsState(initial = emptyList())
    val mostRecent = inspections.firstOrNull()
    val advice = HiveAdvisor.advise(mostRecent)
    val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(hive?.tag ?: "Hive") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        vm.deleteHive(hiveId)
                        onBack()
                    }) { Icon(Icons.Default.Delete, "Delete") }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Honey,
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black,
                    actionIconContentColor = Color.Black
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            hive?.let { h ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(h.tag, style = MaterialTheme.typography.titleLarge)
                            Text(
                                h.location.ifBlank { "No location set" },
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (h.notes.isNotBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(h.notes, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }

            mostRecent?.let { last ->
                item { SectionHeader("Latest signals", dateFmt.format(Date(last.date))) }
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            HoneyFlowBar(last.honeyFlow)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Queen sighted: ${if (last.queenSeen) "Yes" else "No"}  •  " +
                                    "Pests: ${if (last.pestsSeen) "Yes" else "No"}  •  " +
                                    "Activity: ${last.activityLevel.name}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            }

            item { SectionHeader("Advisor") }
            items(advice) { AdviceCard(it) }

            item { Spacer(Modifier.height(4.dp)) }
            item { SectionHeader("Inspection history", "${inspections.size} entries") }
            if (inspections.isEmpty()) {
                item {
                    Text(
                        "No inspections logged yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(inspections) { i ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                dateFmt.format(Date(i.date)),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                "Queen: ${if (i.queenSeen) "✓" else "✗"}  " +
                                    "Pests: ${if (i.pestsSeen) "✓" else "✗"}  " +
                                    "Flow: ${i.honeyFlow}  Activity: ${i.activityLevel}",
                                style = MaterialTheme.typography.bodyMedium
                            )
                            if (i.notes.isNotBlank()) {
                                Spacer(Modifier.height(4.dp))
                                Text(i.notes, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(4.dp)) }
            item { SectionHeader("Harvests", "${harvests.size} entries") }
            if (harvests.isEmpty()) {
                item {
                    Text(
                        "No harvests logged.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(harvests) { h ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            Modifier.padding(14.dp)
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    dateFmt.format(Date(h.date)),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                if (h.notes.isNotBlank()) {
                                    Text(h.notes, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                            Text(
                                "${"%.2f".format(h.quantityKg)} kg",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(40.dp)) }
        }
    }
}
