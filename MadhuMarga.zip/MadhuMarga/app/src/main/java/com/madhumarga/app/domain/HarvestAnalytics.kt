package com.madhumarga.app.domain

import com.madhumarga.app.data.HarvestEntity
import java.util.Calendar

data class YearTotal(val year: Int, val totalKg: Float)

object HarvestAnalytics {
    fun yearOverYear(harvests: List<HarvestEntity>): List<YearTotal> {
        val byYear = harvests.groupBy { year(it.date) }
        return byYear
            .map { (year, items) -> YearTotal(year, items.sumOf { it.quantityKg.toDouble() }.toFloat()) }
            .sortedBy { it.year }
    }

    private fun year(epochMillis: Long): Int {
        val cal = Calendar.getInstance().apply { timeInMillis = epochMillis }
        return cal.get(Calendar.YEAR)
    }
}
