package com.madhumarga.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChecklistRtl
import androidx.compose.material.icons.filled.Hive
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.clickable
import com.madhumarga.app.domain.HiveAdvisor
import com.madhumarga.app.ui.HiveViewModel
import com.madhumarga.app.ui.components.AdviceCard
import com.madhumarga.app.ui.components.SectionHeader
import com.madhumarga.app.ui.theme.Honey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: HiveViewModel,
    onOpenHive: (Long) -> Unit,
    onAddHive: () -> Unit,
    onOpenInspection: () -> Unit,
    onOpenHarvest: () -> Unit,
    onOpenFlora: () -> Unit
) {
    val hives by vm.hives.collectAsState()
    val mostRecent by vm.mostRecentInspection.collectAsState()
    val advice = HiveAdvisor.advise(mostRecent)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Madhu-Marga", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Digital Beekeeper's Diary",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Honey,
                    titleContentColor = Color.Black
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddHive,
                icon = { Icon(Icons.Default.Add, null) },
                text = { Text("New Hive") },
                containerColor = Honey,
                contentColor = Color.Black
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                SectionHeader(
                    "Quick actions",
                    "Log what you see today, then check the advisor."
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QuickActionCard(
                        title = "Inspection",
                        icon = Icons.Default.ChecklistRtl,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenInspection
                    )
                    QuickActionCard(
                        title = "Harvest",
                        icon = Icons.Default.WaterDrop,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenHarvest
                    )
                    QuickActionCard(
                        title = "Flora",
                        icon = Icons.Default.CalendarMonth,
                        modifier = Modifier.weight(1f),
                        onClick = onOpenFlora
                    )
                }
            }

            item { Spacer(Modifier.height(4.dp)) }
            item { SectionHeader("Advisor", "Based on your most recent inspection.") }
            items(advice) { AdviceCard(it) }

            item { Spacer(Modifier.height(4.dp)) }
            item { SectionHeader("Your hives", "${hives.size} registered") }

            if (hives.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Text(
                            "No hives yet. Tap 'New Hive' to register your first one.",
                            modifier = Modifier.padding(16.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            } else {
                items(hives, key = { it.id }) { hive ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onOpenHive(hive.id) },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(20.dp))
                                    .padding(0.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Hive,
                                    null,
                                    tint = Honey,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(hive.tag, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    hive.location.ifBlank { "No location set" },
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@Composable
private fun QuickActionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(
            Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, null, modifier = Modifier.size(28.dp))
            Spacer(Modifier.height(6.dp))
            Text(title, style = MaterialTheme.typography.labelLarge)
        }
    }
}
