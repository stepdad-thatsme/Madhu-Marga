package com.madhumarga.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface HiveDao {
    @Query("SELECT * FROM hives ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<HiveEntity>>

    @Query("SELECT * FROM hives WHERE id = :id")
    fun observeById(id: Long): Flow<HiveEntity?>

    @Query("SELECT * FROM hives WHERE id = :id")
    suspend fun getById(id: Long): HiveEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(hive: HiveEntity): Long

    @Update
    suspend fun update(hive: HiveEntity)

    @Query("DELETE FROM hives WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface InspectionDao {
    @Query("SELECT * FROM inspections WHERE hiveId = :hiveId ORDER BY date DESC")
    fun observeForHive(hiveId: Long): Flow<List<InspectionEntity>>

    @Query("SELECT * FROM inspections ORDER BY date DESC LIMIT 1")
    fun observeMostRecent(): Flow<InspectionEntity?>

    @Query("SELECT * FROM inspections WHERE hiveId = :hiveId ORDER BY date DESC LIMIT 1")
    suspend fun mostRecentForHive(hiveId: Long): InspectionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(inspection: InspectionEntity): Long

    @Query("DELETE FROM inspections WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface HarvestDao {
    @Query("SELECT * FROM harvests ORDER BY date DESC")
    fun observeAll(): Flow<List<HarvestEntity>>

    @Query("SELECT * FROM harvests WHERE hiveId = :hiveId ORDER BY date DESC")
    fun observeForHive(hiveId: Long): Flow<List<HarvestEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(harvest: HarvestEntity): Long

    @Query("DELETE FROM harvests WHERE id = :id")
    suspend fun deleteById(id: Long)
}
