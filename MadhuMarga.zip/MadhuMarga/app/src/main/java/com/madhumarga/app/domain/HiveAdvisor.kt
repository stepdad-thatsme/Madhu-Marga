package com.madhumarga.app.domain

import com.madhumarga.app.data.ActivityLevel
import com.madhumarga.app.data.HoneyFlowLevel
import com.madhumarga.app.data.InspectionEntity

enum class AlertSeverity { INFO, WARNING, CRITICAL }

data class Advice(
    val title: String,
    val message: String,
    val severity: AlertSeverity
)

/**
 * Decision Matrix: turns the last inspection's observations into a prioritized
 * list of recommendations. This is the "simulated GenAI assistant" — a rule-
 * based reasoner the project spec asks for. Replaceable with a real LLM call.
 */
object HiveAdvisor {

    fun advise(inspection: InspectionEntity?): List<Advice> {
        if (inspection == null) {
            return listOf(
                Advice(
                    "Log your first inspection",
                    "Open Inspection Log and record what you see in the hive today.",
                    AlertSeverity.INFO
                )
            )
        }

        val out = mutableListOf<Advice>()

        // Success criterion: intervention alert on Low Activity
        if (inspection.activityLevel == ActivityLevel.LOW) {
            out += Advice(
                "Intervention Alert: Low activity",
                "Bees are unusually quiet. Check for queenlessness, robbing, or pesticide " +
                    "exposure. Consider feeding 1:1 sugar syrup and reducing the entrance.",
                AlertSeverity.CRITICAL
            )
        }

        if (!inspection.queenSeen) {
            out += Advice(
                "Queen not sighted",
                "Look for fresh eggs as a proxy for the queen. If no eggs in 10 days, " +
                    "consider re-queening or combining with a strong colony.",
                AlertSeverity.WARNING
            )
        }

        if (inspection.pestsSeen) {
            out += Advice(
                "Pests detected",
                "Identify the pest (Varroa mites, wax moth, hive beetle). Use screened bottom " +
                    "board, oxalic acid, or formic acid as appropriate for the season.",
                AlertSeverity.WARNING
            )
        }

        when (inspection.honeyFlow) {
            HoneyFlowLevel.HIGH -> out += Advice(
                "Strong honey flow — prepare to harvest",
                "Add a super if you haven't. Plan to extract when frames are ~80% capped.",
                AlertSeverity.INFO
            )
            HoneyFlowLevel.MEDIUM -> out += Advice(
                "Moderate honey flow",
                "Monitor weekly. Ensure the colony has space to store nectar.",
                AlertSeverity.INFO
            )
            HoneyFlowLevel.LOW -> out += Advice(
                "Low honey flow",
                "Scout for blooming flora nearby. Avoid harvesting; the colony may need " +
                    "the stored honey for itself.",
                AlertSeverity.INFO
            )
            HoneyFlowLevel.NONE -> out += Advice(
                "No nectar flow",
                "Consider feeding sugar syrup to maintain colony strength.",
                AlertSeverity.WARNING
            )
        }

        if (inspection.activityLevel == ActivityLevel.HIGH &&
            inspection.honeyFlow == HoneyFlowLevel.HIGH
        ) {
            out += Advice(
                "Consider splitting the colony",
                "High activity + strong flow can lead to swarming. A controlled split " +
                    "into a new box preserves your bees and creates a second colony.",
                AlertSeverity.INFO
            )
        }

        inspection.temperatureC?.let { temp ->
            if (temp > 38f) {
                out += Advice(
                    "Hive overheating",
                    "Provide shade, ventilation, and a shallow water source nearby.",
                    AlertSeverity.WARNING
                )
            } else if (temp < 10f) {
                out += Advice(
                    "Cold stress",
                    "Reduce entrance, ensure the cluster has access to stored honey.",
                    AlertSeverity.WARNING
                )
            }
        }

        if (out.isEmpty()) {
            out += Advice(
                "Hive looks healthy",
                "Queen sighted, normal activity, no pests. Continue weekly inspections.",
                AlertSeverity.INFO
            )
        }

        return out
    }
}
