package com.madhumarga.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.madhumarga.app.data.HiveEntity
import com.madhumarga.app.domain.HarvestAnalytics
import com.madhumarga.app.ui.HiveViewModel
import com.madhumarga.app.ui.components.SectionHeader
import com.madhumarga.app.ui.theme.Honey
import com.madhumarga.app.ui.theme.HoneyDark
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HarvestTrackerScreen(
    vm: HiveViewModel,
    onBack: () -> Unit
) {
    val hives by vm.hives.collectAsState()
    val allHarvests by vm.allHarvests.collectAsState()
    var selectedHive by remember { mutableStateOf<HiveEntity?>(null) }
    var menuExpanded by remember { mutableStateOf(false) }
    var quantityText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    if (selectedHive == null && hives.isNotEmpty()) selectedHive = hives.first()

    val yearTotals = HarvestAnalytics.yearOverYear(allHarvests)
    val maxTotal = yearTotals.maxOfOrNull { it.totalKg }?.takeIf { it > 0f } ?: 1f
    val dateFmt = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Harvest Tracker") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Honey,
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { SectionHeader("Log a harvest", "Record honey extracted from a hive.") }

            if (hives.isEmpty()) {
                item {
                    Text(
                        "Register a hive first.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            } else {
                item {
                    ExposedDropdownMenuBox(
                        expanded = menuExpanded,
                        onExpandedChange = { menuExpanded = !menuExpanded }
                    ) {
                        OutlinedTextField(
                            value = selectedHive?.tag ?: "",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Hive") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(menuExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            hives.forEach { h ->
                                DropdownMenuItem(
                                    text = { Text(h.tag) },
                                    onClick = {
                                        selectedHive = h
                                        menuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it.filter { c -> c.isDigit() || c == '.' } },
                        label = { Text("Quantity (kg)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes (optional)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(90.dp)
                    )
                }
                item {
                    Button(
                        onClick = {
                            val hive = selectedHive ?: return@Button
                            val q = quantityText.toFloatOrNull() ?: return@Button
                            vm.addHarvest(hive.id, q, notes.trim()) {
                                quantityText = ""
                                notes = ""
                            }
                        },
                        enabled = (quantityText.toFloatOrNull() ?: 0f) > 0f,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Save Harvest") }
                }
            }

            item { Spacer(Modifier.height(8.dp)) }
            item {
                SectionHeader(
                    "Year-over-year",
                    "Total honey harvested per year."
                )
            }
            if (yearTotals.isEmpty()) {
                item {
                    Text(
                        "No harvest data yet.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                items(yearTotals) { yt ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    yt.year.toString(),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "${"%.2f".format(yt.totalKg)} kg",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                            Spacer(Modifier.height(6.dp))
                            Box(
                                Modifier
                                    .fillMaxWidth()
                                    .height(12.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.LightGray.copy(alpha = 0.35f))
                            ) {
                                Box(
                                    Modifier
                                        .fillMaxWidth(fraction = (yt.totalKg / maxTotal).coerceIn(0f, 1f))
                                        .height(12.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(HoneyDark)
                                )
                            }
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(8.dp)) }
            item { SectionHeader("All harvests", "${allHarvests.size} entries") }
            items(allHarvests) { h ->
                val hiveTag = hives.firstOrNull { it.id == h.hiveId }?.tag ?: "Hive ${h.hiveId}"
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(
                        Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(hiveTag, style = MaterialTheme.typography.titleMedium)
                            Text(
                                dateFmt.format(Date(h.date)),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (h.notes.isNotBlank()) {
                                Text(h.notes, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        Text(
                            "${"%.2f".format(h.quantityKg)} kg",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            item { Spacer(Modifier.height(60.dp)) }
        }
    }
}
