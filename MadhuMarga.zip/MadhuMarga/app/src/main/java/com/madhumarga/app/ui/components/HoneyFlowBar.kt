package com.madhumarga.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.madhumarga.app.data.HoneyFlowLevel
import com.madhumarga.app.ui.theme.Honey
import com.madhumarga.app.ui.theme.HoneyDark
import com.madhumarga.app.ui.theme.HoneyLight

@Composable
fun HoneyFlowBar(level: HoneyFlowLevel, modifier: Modifier = Modifier) {
    val fraction = when (level) {
        HoneyFlowLevel.NONE -> 0.05f
        HoneyFlowLevel.LOW -> 0.30f
        HoneyFlowLevel.MEDIUM -> 0.65f
        HoneyFlowLevel.HIGH -> 1.0f
    }
    Column(modifier) {
        Text(
            text = "Honey Flow: ${level.name.lowercase().replaceFirstChar { it.uppercase() }}",
            style = MaterialTheme.typography.labelLarge
        )
        Spacer(Modifier.height(6.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(18.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(HoneyLight.copy(alpha = 0.4f))
        ) {
            Box(
                Modifier
                    .fillMaxWidth(fraction)
                    .height(18.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(Honey)
            )
        }
    }
}
