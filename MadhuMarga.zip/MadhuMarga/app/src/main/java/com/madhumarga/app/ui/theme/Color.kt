package com.madhumarga.app.ui.theme

import androidx.compose.ui.graphics.Color

val Honey = Color(0xFFF5B700)
val HoneyDark = Color(0xFFC28E00)
val HoneyLight = Color(0xFFFFD862)
val Leaf = Color(0xFF3F7D3A)
val LeafDark = Color(0xFF2A5A26)
val Earth = Color(0xFF6B4423)
val EarthDark = Color(0xFF4A2E18)
val Cream = Color(0xFFFFF8E7)
val Amber = Color(0xFFE49B0F)
val AlertRed = Color(0xFFB23A2E)
